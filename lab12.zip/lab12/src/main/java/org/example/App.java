package org.example;

public class App
{
    public static void main( String[] args ) {
        System.out.println("Hello, Артем");
        int result = Tester.multiply(12321, 10);
        System.out.println("Результат умножения: " + result);
        Tester tester1 = new Tester("Artem","Volkov",0);

    }
}
