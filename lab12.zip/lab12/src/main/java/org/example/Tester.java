package org.example;

public class Tester extends App {

    protected String name;
    protected String surname;
    protected int expirienceInYears;
    protected String englishLevel;
    protected double salary;

    public Tester(String name, String surname, int expirienceInYears, String englishLevel, double salary) {
        this.name = name;
        this.surname = surname;
        this.expirienceInYears = expirienceInYears;
        this.englishLevel = englishLevel;
        this.salary = salary;
    }

    public Tester(String name, String surname, int expirienceInYears, String englishLevel) {
        this(name, surname, expirienceInYears, englishLevel, 0);
    }

    public Tester(String name, String surname, int expirienceInYears) {
        this(name, surname, expirienceInYears, "B2");
    }

    public static int multiply(int a, int b) {
        return a * b;
    }

    public double salary(Tester name) {
        return name.salary;
    }

    public double salary(Tester name, int count) {
        return name.salary * count;
    }

    public double salary(Tester name, int count, double bonus) {
        return name.salary * count + bonus;
    }
}
